#include<stdio.h>
#include "filaE.h"
#include "filaE.c"

int main(){
 int x;
 FilaE* f;
 PilhaE* p;
 
 f = criar_filaE();
 p = criar_pilhaE();

 enfileirar(7,f);
 enfileirar(-13,f);
 enfileirar(18,f);
 enfileirar(-2,f);
 
 imprimir_fila(f);
    
 while(!filaE_vazia(f)){
     x = desenfileirar(f);
     printf("x = %d\n",x);
	 empilhar(x,p);
 }
 
 imprimir_pilha(p);
    
 liberar_filaE(f);
 liberar_pilha(p);
    
 return 0;
}
