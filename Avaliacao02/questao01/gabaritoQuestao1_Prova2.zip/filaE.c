//filaE.c
#include "pilhaE.h"
#include "pilhaE.c"
#include "filaE.h"

FilaE* criar_filaE(){
  return criar_pilhaE();
}

int filaE_vazia(FilaE* f){
    return (pilhaE_vazia(f));
}
// Enfileirar um item
void enfileirar(int key, FilaE* f){
     empilhar(key,f);
}


// Desenfileirar um item da fila
int desenfileirar(FilaE* f){
    PilhaE* aux;
    aux = criar_pilhaE();
    
    while(!pilhaE_vazia(f))
        empilhar(desempilhar(f),aux);
    
    int valor_topo = desempilhar(aux);
    
    while(!pilhaE_vazia(aux))
        empilhar(desempilhar(aux),f);
    
    liberar_pilha(aux);
    
    return valor_topo;
}



// Imprimir o conteúdo da fila
void imprimir_fila(FilaE* f){
    FilaE* aux;
    aux = criar_filaE();
    while(!filaE_vazia(f)){
         empilhar(desempilhar(f),aux);
    }
    imprimir_pilha(aux);
    while(!filaE_vazia(aux)){
         empilhar(desempilhar(aux),f);
    }
    liberar_pilha(aux);
}


// Desalocar a fila
int liberar_filaE(FilaE* f){
    return liberar_pilha(f);
}

