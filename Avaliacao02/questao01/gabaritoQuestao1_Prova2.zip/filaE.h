//filaE.h
#include "pilhaE.h"

#define FilaE PilhaE

//Protótipo de funções
FilaE* criar_filaE();
int filaE_vazia(FilaE* f);
void enfileirar(int key, FilaE* f);
int desenfileirar(FilaE* f);
void imprimir_fila(FilaE* f);
int liberar_filaE(FilaE* f);
