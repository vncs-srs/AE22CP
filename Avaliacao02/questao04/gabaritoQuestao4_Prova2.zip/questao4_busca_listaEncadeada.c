/***
Refaça as funções de busca sequencial e busca binária
assumindo que a lista possui chaves que podem ocorrer
múltiplas vezes na lista. Neste caso, você deve retornar uma
lista com todas as posições onde a chave foi encontrada. Se a
chave não for encontrada na lista, retornar uma lista vazia.
*/
#include<stdio.h>
#include "listaE.h"
#include "listaE.c"
void busca_sequencial(int x, int v[], int n, ListaE* l);
static int busca_bin(int x, int v[], int ini, int fim, ListaE* l);
int busca_binaria(int x, int v[], int n, ListaE* l);

int main(){
 int v[]= {1,1,1,3,3,5,5,5,5,8,8,8,9,9,9};
 
 ListaE* l = criar_listaE();
 //busca_sequencial(8, v, 15, l);
 busca_binaria(8,v,15,l);
 imprimir(l);
 liberar_LE(l);
 
 return 0;
}
void busca_sequencial(int x, int v[], int n, ListaE* l){
	int i;
	for (i = 0; i < n; i++)
		if (x == v[i])
			inserir_ultimo(i,l);

	return;
}
static int busca_bin(int x, int v[], int ini, int fim, ListaE* l){
	int meio;

	// Caso base, quando ini é igual a fim
	if ((ini == fim) && (x == v[ini]))
    {
        inserir_ultimo(ini,l); 
        //return ini;
    }
	// Em seguida é verificada se ini é menor que fim
	else if (ini < fim){
		// A primeira comparação é sempre no meio do vetor,
		// ou sub-vetor (nas posições entre ini e fim)
		meio = (ini + fim) / 2;

		// E o elemento procurado for o do meio, retorna a posição
		if (x == v[meio])
			//return meio;
            inserir_ultimo(meio,l);
		// Se a chave procurada for menor que a do meio vetor, a
		// busca é continuada na metade inferior
		if (x <= v[meio])
			busca_bin(x, v, ini, meio - 1,l);
		// Caso contrário, a busca é continuada na metade superior
		if (x >= v[meio])
			busca_bin(x, v, meio + 1, fim,l);
	}
}


int busca_binaria(int x, int v[], int n, ListaE* l){
	return busca_bin(x, v, 0, n - 1,l);
}
