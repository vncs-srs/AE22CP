/**
Escreva uma função recursiva que, dada uma string s e um caractere c, conte o número de ocorrências do caractere c na string s.
*/
#include<stdio.h>
#include<string.h>

int conta_char_string(char f[], char c, int tam){
    int aux;
    printf("tam = %d\n",tam);
    if(tam==-1)
        return 0;
    tam = tam -1;
    aux = conta_char_string(f,c,tam);
    if (f[tam]==c)
        return 1 + aux;
    else
        return aux;
    
}

int main(){
  char frase[]={"algoritmos e estruturas de Dados 1!"}; 
  
  int x = conta_char_string(frase,'u',strlen(frase));  
  
  printf("Resultado: %d\n",x);
  
  return 0;   
}
