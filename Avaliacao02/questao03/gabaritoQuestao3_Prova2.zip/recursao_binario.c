/**
Escreva uma função recursiva que, dada uma string s e um caractere c, conte o número de ocorrências do caractere c na string s.
*/
#include<stdio.h>
#include<string.h>

void printf_binario(int n){
    if(n<=1){
      printf("%d",n);
      return;
    }
      else{
      printf_binario(n/2);
      printf("%d",n%2);
    }
}
int main(){
  
  printf_binario(18);  
  
  return 0;   
}
